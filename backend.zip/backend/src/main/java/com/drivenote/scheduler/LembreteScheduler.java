package com.drivenote.scheduler;

import com.drivenote.service.LembreteService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Rotinas automáticas relacionadas a lembretes.
 */
@Component
@RequiredArgsConstructor
public class LembreteScheduler {

    private final LembreteService lembreteService;

    /**
     * Executa diariamente às 00:05.
     * Marca lembretes vencidos como ATRASADO.
     */
    @Scheduled(cron = "0 5 0 * * *")
    public void atualizarLembretesAtrasados() {
        lembreteService.marcarAtrasados();
    }

    /**
     * Executa diariamente às 01:00.
     * Gera novos lembretes baseados nos planos de manutenção.
     */
    @Scheduled(cron = "0 0 1 * * *")
    public void verificarManutencoesVencidas() {
        lembreteService.gerarLembretesManutencaoVencida();
    }
}