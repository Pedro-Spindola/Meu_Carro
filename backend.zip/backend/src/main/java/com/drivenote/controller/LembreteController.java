package com.drivenote.controller;

import com.drivenote.dto.LembreteCreateRequest;
import com.drivenote.dto.LembreteResponse;
import com.drivenote.exception.ApiError;
import com.drivenote.service.LembreteService;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Lembretes", description = "Lembretes automotivos e alertas")
@RestController
@RequestMapping("/api/lembretes")
@RequiredArgsConstructor
public class LembreteController {

    private final LembreteService service;

    @Operation(summary = "Criar lembrete")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Lembrete criado"),
            @ApiResponse(responseCode = "400", description = "Dados inválidos",
                    content = @Content(schema = @Schema(implementation = ApiError.class))),
            @ApiResponse(responseCode = "404", description = "Veículo não encontrado",
                    content = @Content(schema = @Schema(implementation = ApiError.class)))
    })
    @PostMapping
    public LembreteResponse criar(@RequestBody @Valid LembreteCreateRequest request) {
        return service.criar(request);
    }

    @Operation(summary = "Listar lembretes por veículo")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Lista retornada com sucesso"),
            @ApiResponse(responseCode = "404", description = "Veículo não encontrado",
                    content = @Content(schema = @Schema(implementation = ApiError.class)))
    })
    @GetMapping("/veiculo/{veiculoId}")
    public List<LembreteResponse> listar(@PathVariable Long veiculoId) {
        return service.listar(veiculoId);
    }

    @Operation(summary = "Listar todos os lembretes do usuário")
    @GetMapping("/usuario/{usuarioId}")
    public List<LembreteResponse> listarPorUsuario(@PathVariable Long usuarioId) {
        return service.listarPorUsuario(usuarioId);
    }

    @Operation(summary = "Concluir lembrete")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Lembrete concluído"),
            @ApiResponse(responseCode = "404", description = "Lembrete não encontrado",
                    content = @Content(schema = @Schema(implementation = ApiError.class)))
    })
    @PutMapping("/{id}/concluir")
    public LembreteResponse concluir(@PathVariable Long id) {
        return service.concluir(id);
    }

    @Operation(summary = "Processar manutenções vencidas manualmente (Simulação)")
    @PostMapping("/processar-vencidos")
    public void processarVencidos() {
        service.gerarLembretesManutencaoVencida();
    }
}