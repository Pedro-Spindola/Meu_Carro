package com.drivenote.controller;

import com.drivenote.dto.PlanoManutencaoCreateRequest;
import com.drivenote.dto.PlanoManutencaoResponse;
import com.drivenote.exception.ApiError;
import com.drivenote.service.PlanoManutencaoService;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Planos de Manutenção", description = "Planos preventivos de manutenção")
@RestController
@RequestMapping("/api/planos-manutencao")
@RequiredArgsConstructor
public class PlanoManutencaoController {

    private final PlanoManutencaoService service;

    @Operation(
            summary = "Criar plano",
            description = "Cria um plano preventivo. Cada veículo pode ter apenas um plano ativo por tipo."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Plano criado com sucesso"),
            @ApiResponse(responseCode = "400", description = "Dados inválidos ou regra de negócio",
                    content = @Content(schema = @Schema(implementation = ApiError.class))),
            @ApiResponse(responseCode = "404", description = "Veículo não encontrado",
                    content = @Content(schema = @Schema(implementation = ApiError.class))),
            @ApiResponse(responseCode = "409", description = "Plano ativo já existente",
                    content = @Content(schema = @Schema(implementation = ApiError.class)))
    })
    @PostMapping
    public PlanoManutencaoResponse criar(@RequestBody @Valid PlanoManutencaoCreateRequest request) {
        return service.criar(request);
    }

    @Operation(summary = "Listar planos de um veículo")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Lista retornada com sucesso"),
            @ApiResponse(responseCode = "404", description = "Veículo não encontrado",
                    content = @Content(schema = @Schema(implementation = ApiError.class)))
    })
    @GetMapping("/veiculo/{veiculoId}")
    public List<PlanoManutencaoResponse> listar(@PathVariable Long veiculoId) {
        return service.listar(veiculoId);
    }
}