package com.drivenote.entity;

import com.drivenote.enums.TipoCombustivel;
import jakarta.persistence.*;
import lombok.*;

/**
 * Entidade que representa um veículo do usuário.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "veiculos", uniqueConstraints = {
        @UniqueConstraint(name = "uk_veiculo_placa", columnNames = "placa")
})
public class Veiculo extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Usuário dono do veículo.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    /**
     * Marca do veículo (ex: Honda).
     */
    @Column(nullable = false, length = 60)
    private String marca;

    /**
     * Modelo do veículo (ex: Civic).
     */
    @Column(nullable = false, length = 60)
    private String modelo;

    /**
     * Ano de fabricação.
     */
    @Column(nullable = false)
    private Integer ano;

    /**
     * Placa única do veículo.
     */
    @Column(nullable = false, length = 10, unique = true)
    private String placa;

    /**
     * Tipo de combustível.
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TipoCombustivel combustivel;

    /**
     * Quilometragem atual do veículo.
     * Nunca pode diminuir.
     */
    @Column(nullable = false)
    private Long quilometragemAtual;
}