package com.drivenote.service;

import com.drivenote.dto.AbastecimentoCreateRequest;
import com.drivenote.dto.AbastecimentoResponse;
import com.drivenote.entity.Abastecimento;
import com.drivenote.entity.Veiculo;
import com.drivenote.exception.BusinessException;
import com.drivenote.exception.ResourceNotFoundException;
import com.drivenote.mapper.AbastecimentoMapper;
import com.drivenote.repository.AbastecimentoRepository;
import com.drivenote.repository.VeiculoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AbastecimentoService {

    private final AbastecimentoRepository abastecimentoRepository;
    private final VeiculoRepository veiculoRepository;

    public AbastecimentoResponse criar(AbastecimentoCreateRequest request) {
        Veiculo veiculo = veiculoRepository.findById(request.veiculoId())
                .orElseThrow(() -> new ResourceNotFoundException("Veículo não encontrado"));

        if (request.quilometragem() < veiculo.getQuilometragemAtual()) {
            throw new BusinessException("Quilometragem não pode ser menor que a atual do veículo");
        }

        abastecimentoRepository.findTopByVeiculoIdOrderByQuilometragemDesc(veiculo.getId())
                .ifPresent(ultimo -> {
                    if (request.quilometragem() <= ultimo.getQuilometragem()) {
                        throw new BusinessException("Quilometragem deve ser maior que o último abastecimento");
                    }
                });

        BigDecimal valorLitro = request.valorLitro();
        if (valorLitro == null) {
            valorLitro = request.valorTotal()
                    .divide(request.litros(), 2, RoundingMode.HALF_UP);
        }

        BigDecimal consumoMedio = calcularConsumoMedio(request, veiculo);

        BigDecimal custoPorKm = request.valorTotal()
                .divide(BigDecimal.valueOf(request.quilometragem() - veiculo.getQuilometragemAtual()),
                        4, RoundingMode.HALF_UP);

        Abastecimento abastecimento = Abastecimento.builder()
                .veiculo(veiculo)
                .data(request.data())
                .tipoCombustivel(request.tipoCombustivel())
                .valorTotal(request.valorTotal())
                .litros(request.litros())
                .valorLitro(valorLitro)
                .quilometragem(request.quilometragem())
                .consumoMedio(consumoMedio)
                .custoPorKm(custoPorKm)
                .build();

        veiculo.setQuilometragemAtual(request.quilometragem());
        veiculoRepository.save(veiculo);

        return AbastecimentoMapper.toResponse(abastecimentoRepository.save(abastecimento));
    }

    public List<AbastecimentoResponse> listarPorVeiculo(Long veiculoId) {
        return abastecimentoRepository.findAllByVeiculoId(veiculoId)
                .stream().map(AbastecimentoMapper::toResponse).toList();
    }

    public List<AbastecimentoResponse> listarPorPeriodo(Long veiculoId, LocalDate inicio, LocalDate fim) {
        return abastecimentoRepository.findAllByVeiculoIdAndDataBetween(veiculoId, inicio, fim)
                .stream().map(AbastecimentoMapper::toResponse).toList();
    }

    private BigDecimal calcularConsumoMedio(AbastecimentoCreateRequest request, Veiculo veiculo) {
        long kmPercorridos = request.quilometragem() - veiculo.getQuilometragemAtual();
        if (kmPercorridos <= 0) return BigDecimal.ZERO;

        return BigDecimal.valueOf(kmPercorridos)
                .divide(request.litros(), 2, RoundingMode.HALF_UP);
    }
}